#ifndef _TOMORROWLAND_ADT_H_
#define _TOMORROWLAND_ADT_H_

#include <stddef.h> // size_t

/*
Crear un TAD para mantener el estado de las listas de reproduccion de los multiples escenarios de un festival.
El festival tiene 4 escenarios (numerados del 1 al 4), donde, por horarios, en cada escenario toca un DJ. Cada DJ tiene una
lista de canciones que debe poder cargar (se asume que cada nueva cancion se agrega al final de la playlist) y poder luego 
acceder en el orden en la que fueron cargados.
Al inicializar el festival, el mismo comienza sin ningun DJ, y luego se van cargando los DJs uno a uno, asignandole a cada
DJ un escenario y un horario. No se asegura que la carga de los DJs sea por orden de horarios, pero se asume que habra 
pocos horarios vacios en cada escenario (porque cuando tengo un escenario donde no hay nadie tocando, al festival no le sale
rentable). Los horarios se pueden asumir como numeros enteros empezando desde cero, donde cero es la primera hora del festival,
1 es la segunda hora del festival, etc.
Se asume que los sets / shows de cada DJ duran como maximo 1 hora.
Luego de terminar la carga, se debe poder acceder al siguiente DJ, por horario, de manera secuencial, y se puede asumir que,
luego de terminado el show de ese DJ, no se volvera a acceder a la informacion de su playlist.
*/

#define STAGE_COUNT 4
#define DJ_SET_MAX_DURATION 3600

typedef struct tomorrowlandCDT * tomorrowlandADT;

typedef struct {
    char * name;            // Nombre de una cancion
    size_t duration;        // Duracion (en segundos)
} Song;

/// @brief Crea un nuevo festival vacio.
/// @return                 Festival creado.
tomorrowlandADT newFestival();

/// @brief Agrega un DJ al festival, en un determinado escenario, en un determinado horario. Si ya habia un DJ en ese escenario
///        y en ese horario, falla la operacion.
/// @param adt              TAD
/// @param stage            Numero de escenario (1-4). Falla si esta fuera de rango.
/// @param hour             Numero de hora en la que toca ese DJ (de 0 en adelante)
/// @param djName           Nombre del DJ
/// @return                 true si pudo agregar al DJ, false en caso contrario.
bool addDJ(tomorrowlandADT adt, size_t stage, size_t hour, const char * djName);

/// @brief Devuelve el nombre del DJ que esta tocando en un determinado escenario y horario.
/// @param adt              TAD
/// @param stage            Numero de escenario (1-4). Falla si esta fuera de rango.
/// @param hour             Hora en la que esta el DJ. Falla si no hay DJ para ese escenario en esa hora.
/// @return                 Nombre del DJ. NULL en caso de error.
char * getDJName(tomorrowlandADT adt, size_t stage, size_t hour);

/// @brief Agrega una cancion a un DJ, identificado por escenario y por hora. Antes de agregar una cancion debera verificar que 
///                         al agregarla no provoque que el show de ese DJ dure mas de 1 hora.
///                         
/// @param adt              TAD
/// @param stage            Numero de escenario (1-4). Falla si esta fuera de rango.
/// @param hour             Hora en la que esta el DJ al que agregarle la cancion. Falla si no hay DJ para ese escenario en
///                         esa hora.
/// @param song             Cancion a agregar.
/// @return                 true o false dependiendo de si tuvo exito o fallo.
bool addSong(tomorrowlandADT adt, size_t stage, size_t hour, Song song);

/// @brief Devuelve la cantidad de DJs en el festival (en los 4 escenarios).
/// @param adt              TAD
/// @return                 Cantidad de DJs en el festival.
size_t DJCount(tomorrowlandADT adt);

/// @brief Devuelve la duracion total del set de un DJ, identificado por escenario y por hora. La duracion del set es la 
//         suma de las duraciones de las canciones que se tocaron en ese set.
/// @param adt              TAD
/// @param stage            Numero de escenario (1-4). Falla si esta fuera de rango.
/// @param hour             Hora en la que esta el DJ. Falla si no hay DJ para ese escenario en
///                         esa hora.
/// @return                 Duracion total del set del DJ (en segundos). Devuelve -1 en caso de error.
int DJSetDuration(tomorrowlandADT adt, size_t stage, size_t hour);

/// @brief Da inicio al festival. Luego de iniciado el festival, no se pueden agregar nuevos DJs ni nuevas canciones, es decir,
///        addDJ y addSong deberian fallar (devolver false) en caso de ser llamadas luego de iniciado el festival.
/// @param adt              TAD
void startFestival(tomorrowlandADT adt);

/// @brief Devuelve si hay canciones aun sin tocar
/// @param adt 
/// @param stage 
/// @param hour 
/// @return 
bool hasNextSong(tomorrowlandADT adt, size_t stage, size_t hour);

/// @brief Devuelve la proxima cancion en la playlist para un DJ.
/// @param adt              TAD
/// @param stage            Numero de escenario (1-4). Falla si esta fuera de rango.
/// @param hour             Hora en la que esta el DJ al que agregarle la cancion. No hace nada si no hay DJ para ese
///                         escenario en esa hora.
/// @param song             Puntero a la cancion proxima a tocar. No lo modifica si no hay DJ para ese escenario en esa hora.
void nextSong(tomorrowlandADT adt, size_t stage, size_t hour, Song * song);

/// @brief Libera toda la info del TAD.
/// @param adt              TAD
void freeFestival(tomorrowlandADT adt);

#endif // _TOMORROWLAND_ADT_H_
