#include "tomorrowlandADT.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int main(void) {
    char djName[50];
    char songName[50];
    Song song;
    char * s;
    
    // Crear festival
    tomorrowlandADT festival = newFestival();
    assert(festival != NULL);
    assert(DJCount(festival) == 0);

    // Agregar DJs validos
    strcpy(djName, "Miss Monique");
    assert(addDJ(festival, 1, 0, djName));
    assert(DJCount(festival) == 1);
    assert(DJSetDuration(festival, 1, 0) == 0);

    strcpy(djName, "ARTBAT");
    assert(addDJ(festival, 1, 1, djName));
    assert(DJCount(festival) == 2);
    assert(DJSetDuration(festival, 1, 1) == 0);

    strcpy(djName, "Boris Brejcha");
    assert(addDJ(festival, 2, 0, djName));
    assert(DJCount(festival) == 3);
    assert(DJSetDuration(festival, 2, 0) == 0);

    strcpy(djName, "Skrillex");
    assert(addDJ(festival, 2, 1, djName));
    assert(DJCount(festival) == 4);
    assert(DJSetDuration(festival, 2, 1) == 0);

    strcpy(djName, "Monolink");
    assert(addDJ(festival, 3, 0, djName));
    assert(DJCount(festival) == 5);
    assert(DJSetDuration(festival, 3, 0) == 0);

    strcpy(djName, "Green Velvet");
    assert(addDJ(festival, 4, 5, djName));
    assert(DJCount(festival) == 6);
    assert(DJSetDuration(festival, 4, 5) == 0);

    // Agregar DJs en horarios invalidos
    strcpy(djName, "MEDUZA");
    assert(!addDJ(festival, 0, 0, djName)); // Escenario invalido
    assert(DJCount(festival) == 6);
    assert(DJSetDuration(festival, 0, 0) == -1);

    strcpy(djName, "Adam Beyer");
    assert(!addDJ(festival, 5, 0, djName)); // Escenario invalido
    assert(DJCount(festival) == 6);
    assert(DJSetDuration(festival, 5, 0) == -1);

    strcpy(djName, "Argy");
    assert(!addDJ(festival, 1, 1, djName)); // Horario ocupado
    assert(DJCount(festival) == 6);
    assert(DJSetDuration(festival, 1, 1) == 0);

    // Obtener nombre de DJ valido
    assert(strcmp((s = getDJName(festival, 1, 0)), "Miss Monique") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 1, 0)), "Miss Monique") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 1, 1)), "ARTBAT") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 2, 0)), "Boris Brejcha") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 2, 1)), "Skrillex") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 3, 0)), "Monolink") == 0);
    free(s);
    assert(strcmp((s = getDJName(festival, 4, 5)), "Green Velvet") == 0);
    free(s);

    // Obtener nombre de DJ invalido
    assert(getDJName(festival, 0, 0) == NULL);
    assert(getDJName(festival, 5, 0) == NULL);
    assert(getDJName(festival, 1, 2) == NULL);
    assert(getDJName(festival, 2, 2) == NULL);
    assert(getDJName(festival, 3, 1) == NULL);
    assert(getDJName(festival, 4, 0) == NULL);

    // Agregar canciones validas a Miss Monique
    song.name = "16 Red Even";
    song.duration = 180;
    assert(addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 180);

    song.name = "Rain";
    song.duration = 198;
    assert(addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 378);

    song.name = "Nomacita";
    song.duration = 170;
    assert(addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 548);

    strcpy(songName, "Some very long song");
    song.name = songName;
    song.duration = 3000;
    assert(addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 3548);

    strcpy(songName, "Some very short song");
    song.name = songName;
    song.duration = 52;
    assert(addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 3600);

    // Agregar canciones en un set que supera la hora
    song.name = "Subterranean";
    song.duration = 210;
    assert(!addSong(festival, 1, 0, song));
    assert(DJSetDuration(festival, 1, 0) == 3600);

    // Agregar canciones en otro escenario para otro DJ
    song.name = "Bangarang";
    song.duration = 215;
    assert(addSong(festival, 2, 1, song));
    assert(DJSetDuration(festival, 2, 1) == 215);

    song.name = "All Is Fair in Love and Brostep";
    song.duration = 249;
    assert(addSong(festival, 2, 1, song));
    assert(DJSetDuration(festival, 2, 1) == 464);

    song.name = "Purple Lamborghini";
    song.duration = 215;
    assert(addSong(festival, 2, 1, song));
    assert(DJSetDuration(festival, 2, 1) == 679);

    // Agregar canciones en un escenario que no existe
    assert(!addSong(festival, 0, 1, song));
    assert(!addSong(festival, 5, 0, song));

    // Agregar canciones en un horario que no existe
    assert(!addSong(festival, 1, 2, song));
    assert(!addSong(festival, 2, 2, song));
    assert(!addSong(festival, 3, 1, song));
    assert(!addSong(festival, 4, 0, song));

    // Iniciar festival y comprobar que no se pueden agregar nuevos DJs ni canciones
    startFestival(festival);
    assert(!addDJ(festival, 1, 2, "Some DJ"));
    assert(!addSong(festival, 4, 5, song));

    // Obtener una cancion invalida
    assert(!hasNextSong(festival, 1, 2));
    nextSong(festival, 1, 2, &song);
    assert(strcmp(song.name, "Purple Lamborghini") == 0);
    assert(song.duration == 215);

    // Obtener canciones validas
    assert(hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "16 Red Even") == 0);
    assert(song.duration == 180);
    free(song.name);

    assert(hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "Rain") == 0);
    assert(song.duration == 198);
    free(song.name);

    assert(hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "Nomacita") == 0);
    assert(song.duration == 170);
    free(song.name);

    assert(hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "Some very long song") == 0);
    assert(song.duration == 3000);
    free(song.name);

    assert(hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "Some very short song") == 0);
    assert(song.duration == 52);

    // No hay mas canciones
    assert(!hasNextSong(festival, 1, 0));
    nextSong(festival, 1, 0, &song);
    assert(strcmp(song.name, "Some very short song") == 0);
    assert(song.duration == 52);
    free(song.name);

    // Liberar festival
    freeFestival(festival);

    puts("OK!");
    return 0;
}
