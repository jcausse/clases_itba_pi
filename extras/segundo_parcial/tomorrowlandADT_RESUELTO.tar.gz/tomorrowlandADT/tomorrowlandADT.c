#include "tomorrowlandADT.h"

#include <string.h>
#include <stdlib.h>

typedef struct PlaylistSong {
    Song song;
    struct PlaylistSong * nextSong;
} PlaylistSong;

typedef struct {
    char * name;
    int totalDuration;
    PlaylistSong * front;
    PlaylistSong * rear;
} DJ;

typedef struct {
    DJ * djs;
    size_t size;
} Stage;

struct tomorrowlandCDT {
    Stage stages[STAGE_COUNT];
    size_t DJCount;
    bool started;
};

tomorrowlandADT newFestival() {
    return calloc(1, sizeof(struct tomorrowlandCDT));
}

static void initializeDJ(DJ * dj) {
    dj->name = NULL;
    dj->totalDuration = 0;
    dj->front = NULL;
    dj->rear = NULL;
}

static bool isValidDJ(tomorrowlandADT adt, size_t stage, size_t hour) {
    if (stage < 1 ||  stage > STAGE_COUNT) {            // Chequeo que el escenario sea valido
        return false;
    }
    stage--;

    if (adt->stages[stage].size <= hour) {              // Chequeo que la hora sea valida
        return false;
    }

    if (adt->stages[stage].djs[hour].name == NULL) {    // Chequeo que el DJ este creado
        return false;
    }

    return true;
}

bool addDJ(tomorrowlandADT adt, size_t stage, size_t hour, const char * djName) {
    // Precondiciones
    if (stage < 1 || stage > STAGE_COUNT || djName == NULL || adt->started) {
        return false;
    }
    stage--;    // Convierto el numero de escenario a indice del arreglo

    // Caso 1: horario ya ocupado para ese escenario
    if (hour < adt->stages[stage].size && adt->stages[stage].djs[hour].name != NULL) {
        return false;
    }

    // Caso 2.1: tengo que agrandar el arreglo
    if (hour >= adt->stages[stage].size) {
        adt->stages[stage].djs = realloc(adt->stages[stage].djs, sizeof(DJ) * (hour + 1));
        for (size_t i = adt->stages[stage].size; i < hour + 1; i++) {
            initializeDJ(&(adt->stages[stage].djs[i]));
        }
        (adt->stages[stage].size) = hour + 1;
    }

    // Caso 2.2: no era necesario agrandar el arreglo (+ continuacion del caso 2.1)
    adt->stages[stage].djs[hour].name = strdup(djName);
    (adt->DJCount)++;
    return true;
}

char * getDJName(tomorrowlandADT adt, size_t stage, size_t hour) {
    if (!isValidDJ(adt, stage, hour)) {
        return NULL;
    }

    return strdup(adt->stages[stage - 1].djs[hour].name);
}

bool addSong(tomorrowlandADT adt, size_t stage, size_t hour, Song song) {
    // Precondiciones
    if (!isValidDJ(adt, stage, hour) || adt->started) {
        return false;
    }
    DJ * dj = &(adt->stages[stage - 1].djs[hour]);

    // No me tengo que pasar de 1h por set
    if (dj->totalDuration + song.duration > DJ_SET_MAX_DURATION) {
        return false;
    }

    // Creo la nueva cancion
    PlaylistSong * newSong = malloc(sizeof(PlaylistSong));
    newSong->song.name = strdup(song.name);
    newSong->song.duration = song.duration;
    newSong->nextSong = NULL;

    // Insertar la cancion en la playlist
    // Caso 1: cola vacia
    if (dj->rear == NULL) {
        dj->rear = newSong;
        dj->front = newSong;
    }
    // Caso 2: cola no vacia
    else {
        dj->rear->nextSong = newSong;
        dj->rear = newSong;
    }

    // Aumentar la duracion
    dj->totalDuration += song.duration;

    return true;
}

size_t DJCount(tomorrowlandADT adt) {
    return adt->DJCount;
}

int DJSetDuration(tomorrowlandADT adt, size_t stage, size_t hour) {
    if (!isValidDJ(adt, stage, hour)) {
        return -1;
    }

    return adt->stages[stage - 1].djs[hour].totalDuration;
}

void startFestival(tomorrowlandADT adt) {
    adt->started = true;
}

bool hasNextSong(tomorrowlandADT adt, size_t stage, size_t hour) {
    // Precondiciones
    if (!isValidDJ(adt, stage, hour)) {
        return false;
    }
    return adt->stages[stage - 1].djs[hour].front != NULL;
}

void nextSong(tomorrowlandADT adt, size_t stage, size_t hour, Song * song) {
    // Precondiciones
    if (!isValidDJ(adt, stage, hour) || !hasNextSong(adt, stage, hour)) {
        return;
    }
    DJ * dj = &(adt->stages[stage - 1].djs[hour]);

    song->name = dj->front->song.name;          // NO HACER strdup
    song->duration = dj->front->song.duration;

    PlaylistSong * toFree = dj->front;

    dj->front = dj->front->nextSong;

    free(toFree);
}

static void freePlaylist(PlaylistSong * playlist) {
    if (playlist == NULL) {
        return;
    }
    freePlaylist(playlist->nextSong);
    free(playlist->song.name);
    free(playlist);
}

static void freeDJ(DJ * dj) {
    if (dj->name == NULL){
        return;
    }
    free(dj->name);
    freePlaylist(dj->front);
}

void freeFestival(tomorrowlandADT adt) {
    for (size_t i = 0; i < STAGE_COUNT; i++) {
        for (size_t j = 0; j < adt->stages[i].size; j++) {
            freeDJ(&(adt->stages[i].djs[j]));
        }
        free(adt->stages[i].djs);
    }
    free(adt);
}
